# feedback_app/forms.py
from django import forms

class FeedbackForm(forms.Form):
    email = forms.EmailField(label="Your Email", max_length=254)
    feedback = forms.CharField(label="Your Feedback", widget=forms.Textarea)
