from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth import authenticate,login,logout
from django.core.mail import send_mail
from .models import Feedback
from .forms import FeedbackForm
from django.conf import settings


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Create your views here.
def home(request):
    return render(request, 'index.html')

def About(request):
    return render(request,'about.html')

def Contact(request):
    return render(request,'contact.html')

def Index(request):
    if not request.user.is_staff:
        return redirect('login')
    doctors=Doctor.objects.all()
    patient=Patient.objects.all()
    appointment=Appointment.objects.all()
    d = 0;
    p = 0;
    a = 0;
    for i in doctors:
        d+=1   
    for i in patient:
        p+=1    
    for i in appointment:
        a+=1   
    d1 = {'d':d,'p':p,'a':a}
    return render(request, 'index.html',d1)

def Login(request):
    error=""
    if request.method=='POST':
        u = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=u,password=p)
        try:
            if user.is_staff:
                login(request,user)
                error="no"
            else:
                error="yes"
        except:
            error="yes"       
    d = {'error':error}
    return render(request, 'login.html',d)


def Logout_admin(request):
    if not request.user.is_staff:
        return redirect('login')
    
    logout(request)
    return redirect('login')


def View_Doctor(request):
    if not request.user.is_staff:
        return redirect('login')
    
    doc = Doctor.objects.all()
    d = {'doc':doc}
    return render(request,'view_doctor.html',d)
    
    
def Add_Doctor(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')
    if request.method=='POST':
        n = request.POST['name']
        c = request.POST['contact']
        sp = request.POST['special']
        
        try:
            Doctor.objects.create(name=n,mobile=c,special=sp)
            error="no"               
        except:
            error="yes"
           
    d = {'error':error}
    return render(request, 'add_doctor.html',d)


def Delete_Doctor(request,id):
    if not request.user.is_staff:
        return redirect('login')
    doctor = Doctor.objects.get(id=id)
    doctor.delete()
    return redirect('view_doctor')
    
    
def View_Patient(request):
    if not request.user.is_staff:
        return redirect('login')
    
    pat = Patient.objects.all()
    p = {'pat':pat}
    return render(request,'view_patient.html',p)
    
    
def Add_Patient(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')
    if request.method=='POST':
        n = request.POST['name']
        g = request.POST['gender']
        m = request.POST['mobile']
        a = request.POST['address']
        
        try:
            Patient.objects.create(name=n,gender=g,mobile=m,address=a)
            error="no"               
        except:
            error="yes"
           
    p = {'error':error}
    return render(request, 'add_patient.html',p)


def Delete_Patient(request,id):
    if not request.user.is_staff:
        return redirect('login')
    patient = Patient.objects.get(id=id)
    patient.delete()
    return redirect('view_patient')



def View_Appointment(request):
    if not request.user.is_staff:
        return redirect('login')
    
    appoint = Appointment.objects.all()
    a = {'appoint':appoint}
    return render(request,'view_appointment.html',a)
    
    
def Add_Appointment(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')
    
    doctor1 = Doctor.objects.all()
    patient1 = Patient.objects.all()
    
    
    if request.method=='POST':
        d = request.POST['doctor']
        p = request.POST['patient']
        d1 = request.POST['date1']
        t = request.POST['time1']
        
        doctor = Doctor.objects.filter(name=d).first()
        patient = Patient.objects.filter(name=p).first()
        
        try:
            Appointment.objects.create(doctor=doctor,patient=patient,date1=d1,time1=t)
            error="no"               
        except:
            error="yes"
           
    a = {'doctor':doctor1,'patient':patient1,'error':error}
    return render(request, 'add_appointment.html',a)


def Delete_Appointment(request,id):
    if not request.user.is_staff:
        return redirect('login')
    appointment = Appointment.objects.get(id=id)
    appointment.delete()
    return redirect('view_appointment')
    
    
def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            # Save feedback to the database
            feedback_instance = Feedback(
                email=form.cleaned_data['email'],
                feedback=form.cleaned_data['feedback']
            )
            feedback_instance.save()

            # Send thank-you email
            send_mail(
                'Thank You for Your Feedback',
                'We appreciate your feedback and will use it to improve our services.',
                settings.DEFAULT_FROM_EMAIL,
                [form.cleaned_data['email']],
                fail_silently=False,
            )

            return redirect('feedback_thanks')  # Redirect to a thank-you page
    else:
        form = FeedbackForm()

    return render(request, 'feedback_form.html', {'form': form})

def feedback_thanks(request):
    return render(request, 'thanks.html')



def Diabetes(request):
    return render(request, 'Diabetes.html')


def Predict(request):
    return render(request, 'Predict.html')


def Result(request):
    data = pd.read_csv("static\Diabetes.csv")
    X = data.drop("Outcome", axis=1)
    Y = data['Outcome']
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)
    model = LogisticRegression()
    model.fit(X_train, Y_train)
    val1 = float(request.GET['n1'])
    val2 = float(request.GET['n2'])
    val3 = float(request.GET['n3'])
    val4 = float(request.GET['n4'])
    val5 = float(request.GET['n5'])
    val6 = float(request.GET['n6'])
    val7 = float(request.GET['n7'])
    val8 = float(request.GET['n8'])
    
    pred = model.predict([[val1, val2, val3, val4, val5, val6, val7, val8]])
    
    result1 = ""
    if pred==[1]:
        result1 = "Positive"
    else:
        result1 = "Negative"
    return render(request, "predict.html", {"result2":result1})
    